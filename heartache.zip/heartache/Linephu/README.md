# ![logo](/assets/LINE-sm.png) LINE Protocol
 [![LICENSE](https://img.shields.io/badge/license-GPL%203.0-blue.svg "LICENSE")](https://github.com/fadhiilrachman/line-protocol/blob/master/LICENSE) [![Chat on Discord](https://img.shields.io/badge/chat-on%20discord-7289da.svg "Chat on Discord")](https://discord.gg/JAA2uk6)

*LINE Messaging's private protocol*

----

This work is **no way** affiliated with LINE Corporation or Naver. These files are the results of research into the LINE Messaging protocol.

## Special Thanks
- Matti Virkkunen / [@mvirkkunen](https://github.com/mvirkkunen)
- ぐるぐる / [@f0reachARR](https://github.com/f0reachARR)
- GoogleX133 / [@GoogleX133](https://github.com/GoogleX133)
